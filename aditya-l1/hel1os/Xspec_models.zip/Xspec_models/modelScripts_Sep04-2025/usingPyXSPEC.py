# July 11, 2025
from xspec import *
from solarflaremodels import standardthick, thickvnorm, thickrc, standardthin
pha1 = 'czt_typeI_pha.fits'
AllData(f"1:1 {pha1}")
stdthickinfo = (
    "p       \"\"   3.0    1.5   1.5   10.0   10.0   0.01",
    "eebrk   keV  200.0  5.0    5.0    500.0  1e6    1.0",
    "q       \"\"   6.0    1.5   1.5   15.0   15.0   0.01",
    "eelow   keV  40.0   20.0    20.0    100.0  150.0  0.01",
    "eehigh  keV  4e4    100.0  200.0  1e5    1e6    1.0",
)

AllModels.addPyMod(standardthick, stdthickinfo, 'add')
m1 = Model("standardthick")

# defining the model parameters
p1 = m1.standardthick.p
p1.values = 6.0
# eebrk, i.e. the break energy of the electron spectrum. This works only if we assume that the electron distribution follows a broken-power law. We are assuming this to be a single power-law
p2 = m1.standardthick.eebrk
p2.values = 4e4 # we are setting this to be equal to eehigh
p2.frozen = True # freezing this
# power law index of the electron spectrum, after the break
p3 = m1.standardthick.q
p3.frozen = True # freezing this
# low-energy cutoff of the electron spectrum - since our detector has a low-energy threshold of 20 keV, the lowest electron photon energy that it can, in principle detector, is 20 keV. This means the lowest energy electron that can produce the 20 keV photon, is 21 keV. We are not changing the value now.
# eehigh, i.e the high-energy cut-off of the electron distribution, let's just freez
e it for now
p5 = m1.standardthick.eehigh
p5.frozen = True
# Setting the range for fitting
fitstart = 35.0
fitend   = 100.0
# Ignore everything outside the selected filters ===================================
s1=AllData(1)
s1.ignore(f"**-{fitstart} {fitend}-**")
# Fit!! 
Fit.perform()
"""
computing the reduced chi-square; ratio of chi-square and number of free parameters
171.31/153 => 1.1196732026143792
"""
#=====================================================================================
# July 29, 2025 
from xspec import *
from solarflaremodels import warmthick
pha1 = 'czt_typeI_pha.fits'
AllData(f"1:1 {pha1}")
# In your main analysis script...

# Info for the 'warmthick' model (9 shape params + norm)
warmthick_info = (
    "p_nt    \"\"   3.5   -2.0  -1.0  10.0  11.0  0.1",   # Non-thermal p
    "ebrk_nt keV  60.0  5.0   5.0   500.0 1e3   -1.0",  # Non-thermal eebrk
    "q_nt    \"\"   3.5   -2.0  -1.0  15.0  15.0  0.1",   # Non-thermal q
    "elow_nt keV  25.0  10.0  10.0  100.0 150.0  0.5",  # Non-thermal eelow
    "ehigh_nt keV 1e5   -1    -1    -1    -1    -1",     # Non-thermal eehigh
    "dens_w  10^10cm-3 1.0  0.01  0.1   100.0 100.0 0.1", # Warm plasma density
    "temp_w  keV  2.0   0.1   0.5   20.0  30.0  0.1",   # Warm plasma temperature
    "len_w   Mm   10.0  1.0   1.0   100.0 200.0 1.0",   # Warm plasma length
    "abund   ,,   1.0   -1    -1    -1    -1    -1"      # Abundance (frozen)
)
AllModels.addPyMod(warmthick, warmthick_info, 'add')
m1 = Model("warmthick")

# defining the model parameters
p1 = m1.warmthick.p_nt
p1.values = 6.0
# eebrk, i.e. the break energy of the electron spectrum. This works only if we assume that the electron distribution follows a broken-power law. We are assuming this to be a single power-law
p2 = m1.warmthick.ebrk_nt
p2.values = 4e4 # we are setting this to be equal to eehigh
p2.frozen = True # freezing this
# power law index of the electron spectrum, after the break
p3 = m1.warmthick.q_nt
p3.frozen = True # freezing this

# low-energy cutoff of the electron spectrum - since our detector has a low-energy threshold of 20 keV, the lowest electron photon energy that it can, in principle detector, is 20 keV. This means the lowest energy electron that can produce the 20 keV photon, is 21 keV. We are not changing the value now.

# eehigh, i.e the high-energy cut-off of the electron distribution, let's just freeze it for now
p5 = m1.warmthick.ehigh_nt
p5.frozen = True
# Setting the range for fitting
fitstart = 35.0
fitend   = 100.0
# Ignore everything outside the selected filters ===================================
s1=AllData(1)
s1.ignore(f"**-{fitstart} {fitend}-**")
# Fit!! 
Fit.perform()


# ================================
# Info for the 'thicknui' model (5 shape params + norm)
thicknui_info = (
    "p       \"\"   3.5   1.5   1.5   10.0  10.0   0.01",  # Electron power-law index
    "E_star  keV  30.0  0.0   0.0   100.0 150.0  0.5",   # E* (step-func) or E1 (linear-func)
    "E0-E1   keV  0.0   -1    -1    -1    -1     -1",    # Difference for linear func (frozen for step-func)
    "eelow   keV  25.0  10.0  10.0  100.0 150.0  0.5",  # Low-energy cutoff
    "eehigh  keV  1e5   -1    -1    -1    -1     -1"     # High-energy cutoff (frozen)
)
AllModels.addPyMod(thicknui, thicknui_info, 'add')
print("Custom model 'thicknui' successfully loaded.")


# Info for the 'thkappa' model (3 shape params + norm)
thkappa_info = (
    "kT      keV  2.0   0.1   0.5   20.0  30.0   0.1",   # Temperature in keV
    "kappa   \"\"   3.0   1.51  1.6   10.0  20.0   0.1",   # Kappa index (>1.5)
    "ehigh   keV  1e5   -1    -1    -1    -1     -1"     # High-energy cutoff (frozen)
)
AllModels.addPyMod(thkappa, thkappa_info, 'add')
print("Custom model 'thkappa' successfully loaded.")

# Info for 'thwarmkappa' (7 shape params + norm)
thwarmkappa_info = (
    "p_kappa  \"\"   3.0   2.1   2.2   10.0  20.0   0.1",   # Kappa power-law index (>2)
    "T_kappa  keV  50.0  10.0  10.0  500.0 1e3    1.0",   # Kappa temperature
    "ehigh    keV  1e5   -1    -1    -1    -1     -1",    # High-energy cutoff (frozen)
    "dens_w   10^10cm-3 1.0  0.01  0.1   100.0 100.0 0.1", # Warm plasma density
    "temp_w   keV  2.0   0.1   0.5   20.0  30.0  0.1",   # Warm plasma temperature
    "len_w    Mm   10.0  1.0   1.0   100.0 200.0 1.0",   # Warm plasma length
    "abund    \"\" 1.0   -1    -1    -1    -1    -1"      # Abundance (frozen)
)
AllModels.addPyMod(thwarmkappa, thwarmkappa_info, 'add')
