# July 03, 2025
# Manju Sudhakar
import numpy as np
from scipy.special import gamma
"""
Contents of the helper function script:
(1) brm_bremcross
(2) brm_eloss
(3) brm_gauleg
(4) The electron distributions: 
    (a) brm2_distrn (value of the standard distribution)
    (b) brm2_f_distrn (integral of the standard distribution)
    (c) brm2_f_distrn_vnorm (integral of the v-norm distribution)
    (d) brm2_frc_distrn_vnorm (integral of the return-current distribution)
(5) The thin-target functions: 
    (a) brm2_fthin (thin-target integrand)
    (b) brm2_dmlin (thin-target integrator)
(6) The thick-target functions:
    (a) brm2_check_energies
    (b) brm2_fouter
    (c) brm2_dmlino_int
    (d) brm2_dmlino
    (e) brm2_thicktarget
"""


def brm_bremcross(eel, eph, z):
    """
    Computes the relativistic cross section for electron-ion bremsstrahlung,
    differential in photon energy.

    This is a Python translation of the HESSI IDL procedure Brm_BremCross.pro.
    The cross section is from Equation (4) of E. Haug (Astron. Astrophys. 326,
    417, 1997), which is a close approximation of Formula 3BN of H. W. Koch & J. W. Motz
    (Rev. Mod. Phys. 31, 920, 1959). The Elwert factor is also included.

    Parameters
    ----------
    eel : np.ndarray
        Array of electron kinetic energies (abscissas) at which to compute
        the bremsstrahlung cross section (in keV).
    eph : np.ndarray
        Array of photon energies corresponding to the electron energies in eel
        (in keV).
    z : float
        Mean atomic number of the target plasma.

    Returns
    -------
    cross : np.ndarray
        Array of bremsstrahlung cross sections in units of cm^2, corresponding
        to the input arrays.
    """
    # --- Physical and numerical coefficients ---
    mc2 = 510.98  # Electron rest mass energy in keV 
    alpha = 7.29735308e-03  # Fine-structure constant 
    twoar02 = 1.15893512e-27  # 2 * alpha * (classical electron radius)^2 

    c11 = 4.0 / 3.0
    c12 = 7.0 / 15.0
    c13 = 11.0 / 70.0
    c21 = 7.0 / 20.0
    c22 = 9.0 / 28.0
    c23 = 263.0 / 210.0
    # 

    # --- Calculate normalized photon and total electron energies ---
    k = eph / mc2  # Normalized photon energy 
    e1 = (eel / mc2) + 1.0  # Total initial electron energy in units of mc^2 

    # --- Calculate energies of scattered electrons and normalized momenta ---
    e2 = e1 - k
    p1 = np.sqrt(e1**2 - 1.0)
    p2 = np.sqrt(e2**2 - 1.0)
    # 

    # --- Define frequently used quantities ---
    e1e2 = e1 * e2
    p1p2 = p1 * p2
    p2sum = p1**2 + p2**2
    k2 = k**2
    e1e23 = e1e2**3
    pe = p2sum / e1e23
    # 

    # --- Define terms in cross section ---
    ch1 = (c11 * e1e2 + k2) - (c12 * k2 / e1e2) - (c13 * k2 * pe / e1e2)
    ch2 = 1.0 + (1.0 / e1e2) + (c21 * pe) + (c22 * k2 + c23 * p1p2**2) / e1e23
    # 

    # --- Collect terms ---
    # np.log is the natural logarithm, equivalent to IDL's Alog
    log_term = 2.0 * np.log((e1e2 + p1p2 - 1.0) / k)
    crtmp = ch1 * (log_term - (p1p2 / e1e2) * ch2)
    crtmp = z**2 * crtmp / (k * p1**2)

    # --- Compute the Elwert factor ---
    a1 = alpha * z * e1 / p1
    a2 = alpha * z * e2 / p2
    # np.pi is equivalent to IDL's !dpi
    fe = (a2 / a1) * (1.0 - np.exp(-2.0 * np.pi * a1)) / (1.0 - np.exp(-2.0 * np.pi * a2))
    # 
    
    # --- Compute the final differential cross section (units cm^2) ---
    cross = twoar02 * fe * crtmp # 

    return cross


#---------------------------------------------------------------------------------------------

def brm_eloss(eel):
    """
    Computes the energy-dependent terms of the collisional energy loss rate for
    energetic electrons.

    This is a Python translation of the HESSI IDL procedure Brm_ELoss.pro.
    The full energy loss rate is `decoeff * dedt`, where `decoeff` is computed
    in the main thick-target routines (e.g., brm_bremthick). This function
    returns only the `dedt` part.

    Parameters
    ----------
    eel : np.ndarray
        Array of electron kinetic energies (in keV) at which to compute the
        energy-dependent terms of the energy loss rate.

    Returns
    -------
    dedt : np.ndarray
        Array of the energy-dependent terms of the energy loss rates
        corresponding to the input array `eel`.
    """
    mc2 = 510.98  # Electron rest mass energy in keV

    # Calculate gamma (Lorentz factor) and beta (speed/c)
    gamma = (eel / mc2) + 1.0
    beta = np.sqrt(1.0 - 1.0 / gamma**2)

    # Calculate the energy-dependent term of the loss rate.
    # np.log is the natural logarithm, equivalent to IDL's ALog.
    dedt = np.log(6.9447e+09 * eel) / beta

    return dedt

#---------------------------------------------------------------------------------------------
# July 07, 2025 (replaces the old brm_gauleg)

def brm_gauleg(x1, x2, n):
    """
    Computes the abscissas and weights for Gauss-Legendre quadrature.
    (Corrected to handle scalar/array input combinations)
    """
    eps = 3.0e-14

    # --- FIX: Determine the output size based on whichever input is an array ---
    if isinstance(x1, np.ndarray) and x1.ndim > 0:
        n_rows = len(x1)
    elif isinstance(x2, np.ndarray) and x2.ndim > 0:
        n_rows = len(x2)
    else:
        n_rows = 1 # Both inputs are scalars

    # Ensure inputs are at least 1D for broadcasting to work correctly
    x1 = np.atleast_1d(x1)
    x2 = np.atleast_1d(x2)

    # Initialize output arrays with the correct number of rows
    x = np.zeros((n_rows, n))
    w = np.zeros((n_rows, n))
    # -------------------------------------------------------------------------
    
    m = (n + 1) // 2
    xm = 0.5 * (x2 + x1)
    xl = 0.5 * (x2 - x1)
    
    for i in range(1, m + 1):
        z = np.cos(np.pi * (i - 0.25) / (n + 0.5))
        while True:
            p1, p2 = 1.0, 0.0
            for j in range(1, n + 1):
                p3, p2 = p2, p1
                p1 = ((2.0 * j - 1.0) * z * p2 - (j - 1.0) * p3) / j

            pp = n * (z * p1 - p2) / (z**2 - 1.0)
            z1 = z
            z = z1 - p1 / pp
            if np.all(np.abs(z - z1) <= eps):
                break

        x[:, i - 1] = xm - xl * z
        x[:, n - i] = xm + xl * z
        w_val = 2.0 * xl / ((1.0 - z**2) * pp**2)
        w[:, i - 1] = w_val
        w[:, n - i] = w_val

    return x, w

#---------------------------------------------------------------------------------------------

def brm2_distrn(eel, p, q, elow, ebrk, ehigh, func=None):
    """
    Calculates the value of the normalized, double power-law electron
    distribution function at given electron energies.

    This is a Python translation of the HESSI IDL procedure Brm2_Distrn.pro.
    The distribution function is normalized so that the integral from elow to
    ehigh is 1.

    Parameters
    ----------
    eel : np.ndarray
        Array of electron energies (in keV) at which to calculate the function.
    p : float
        Power-law index of the electron distribution function below ebrk.
    q : float
        Power-law index of the electron distribution function above ebrk.
    elow : float
        Low-energy cutoff of the distribution (in keV).
    ebrk : float
        Break energy of the distribution (in keV).
    ehigh : float
        High-energy cutoff of the distribution (in keV).
    func : str, optional
        A string indicating a specific model variant that modifies energy
        parameters, e.g., 'thick2_rc'. Default is None.

    Returns
    -------
    fcn : np.ndarray
        Array containing the value of the normalized electron distribution
        function for each element of the input array `eel`.
    """
    # Protect input arguments from being modified by creating local copies
    eelow = float(elow)
    eebrk = float(ebrk)
    eehigh = float(ehigh)

    # For thick2_rc model, eebrk is the potential drop, not the break energy.
    # The distribution becomes a single power-law. 
    if func == 'thick2_rc':
        eelow = eelow + eebrk
        eehigh = eehigh + eebrk
        eebrk = eehigh
    elif func == 'thick_nui':
        eebrk = eehigh

    # --- Obtain normalization coefficient, norm ---
    # This calculation assumes p and q are not equal to 1.
    n0 = (q - 1.0) / (p - 1.0) * eebrk**(p - 1.0) * eelow**(1.0 - p)
    n1 = n0 - (q - 1.0) / (p - 1.0)
    n2 = 1.0 - eebrk**(q - 1.0) * eehigh**(1.0 - q)
    norm = 1.0 / (n1 + n2)
    #

    # Initialize the output array with zeros
    fcn = np.zeros_like(eel, dtype=float)

    # --- Calculate value of distribution function for different energy regimes ---

    # 1. For energies between elow and ebrk
    # Find indices where eel is within this range
    ind1 = np.where((eel >= eelow) & (eel < eebrk))
    if ind1[0].size > 0:
        fcn[ind1] = norm * n0 * (p - 1.0) * (eel[ind1]**-p) * (eelow**(p - 1.0))

    # 2. For energies between ebrk and ehigh
    # Find indices where eel is within this range
    ind2 = np.where((eel >= eebrk) & (eel <= eehigh))
    if ind2[0].size > 0:
        fcn[ind2] = norm * (q - 1.0) * (eel[ind2]**-q) * (eebrk**(q - 1.0))
        
    # For energies below elow or above ehigh, fcn remains 0.

    return fcn

#-------------------------------------------------------------------------------------------
def brm2_f_distrn(eel, p, q, eelow, eebrk, eehigh):
    """
    Provides the integral of the double power-law electron flux distribution
    function from eel to eehigh. The distribution function is normalized so
    that the integral from eelow to eehigh is 1.

    This is a Python translation of the HESSI IDL procedure Brm2_F_Distrn.pro.

    Parameters
    ----------
    eel : np.ndarray
        Array of electron energies (in keV) which are the lower limits for
        the integration.
    p, q : float
        Power-law indices below and above the break energy.
    eelow, eebrk, eehigh : float
        Low-energy cutoff, break energy, and high-energy cutoff (keV).

    Returns
    -------
    F_E : np.ndarray
        Array containing the integrated electron flux distribution function.
    """
    # Obtain normalization coefficient, norm
    n0 = (q - 1.0) / (p - 1.0) * eebrk**(p - 1.0) * eelow**(1.0 - p)
    n1 = n0 - (q - 1.0) / (p - 1.0)
    n2 = 1.0 - eebrk**(q - 1.0) * eehigh**(1.0 - q)
    norm = 1.0 / (n1 + n2)

    F_E = np.zeros_like(eel, dtype=float)

    # --- Apply formulas for the three energy regimes ---

    # 1. For lower integration limits below eelow
    # The integral is from eelow to eehigh, which is 1 by definition.
    ind1 = np.where(eel < eelow)
    if ind1[0].size > 0:
        F_E[ind1] = 1.0

    # 2. For lower integration limits between eelow and eebrk
    ind2 = np.where((eel >= eelow) & (eel < eebrk))
    if ind2[0].size > 0:
        term1 = n0 * eelow**(p - 1.0) * eel[ind2]**(1.0 - p)
        term2 = (q - 1.0) / (p - 1.0)
        F_E[ind2] = norm * (term1 - term2 + n2)

    # 3. For lower integration limits between eebrk and eehigh
    ind3 = np.where((eel >= eebrk) & (eel <= eehigh))
    if ind3[0].size > 0:
        term1 = eebrk**(q - 1.0) * eel[ind3]**(1.0 - q)
        term2 = 1.0 - n2
        F_E[ind3] = norm * (term1 - term2)

    # For eel > eehigh, the integral is 0, which is already the default value.

    return F_E

#---------------------------------------------------------------------------------------------------

def brm2_f_distrn_vnorm(eel, p, q, eelow, eebrk, eehigh, Eexp=None, ref_energy=50.0):
    """
    Provides the integral of the double power-law electron flux distribution
    function from eel to eehigh, normalized to the spectral flux at a
    reference energy.

    This is a Python translation of the HESSI IDL procedure Brm2_F_Distrn_vnorm.pro.
    If eelow < ref_energy < eebrk, the normalization is the electron spectral
    flux (electrons per sec per keV) at ref_energy.

    Parameters
    ----------
    eel : np.ndarray
        Array of electron energies (in keV) which are the lower limits for
        the integration.
    p, q : float
        Power-law indices below and above the break energy.
    eelow, eebrk, eehigh : float
        Low-energy cutoff, break energy, and high-energy cutoff (keV).
    Eexp : float, optional
        Exponential rolloff energy (in keV). If provided, an exponential
        factor is applied. Default is None.
    ref_energy : float, optional
        The reference energy for normalization (in keV). Defaults to 50.0.

    Returns
    -------
    F_E : np.ndarray
        Array containing the integrated electron flux distribution function.
    """
    eeref = ref_energy

    # Clip eebrk to be within the valid energy range 
    if eebrk > eehigh:
        eebrk = eehigh
    if eebrk < eelow:
        eebrk = eelow

    # Normalize all energies to the reference energy, eeref 
    een = eel / eeref
    eln = eelow / eeref
    ebn = eebrk / eeref
    ehn = eehigh / eeref

    F_E = np.zeros_like(eel, dtype=float)

    # --- Apply formulas for the three energy regimes using normalized energies ---

    # 1. For eel < eelow
    ind1 = np.where(eel < eelow)
    if ind1[0].size > 0:
        term1 = (eln**(1.0 - p) - ebn**(1.0 - p)) / (p - 1.0)
        term2 = (ebn**(q - p)) * (ebn**(1.0 - q) - ehn**(1.0 - q)) / (q - 1.0)
        F_E[ind1] = term1 + term2

    # 2. For eelow <= eel < eebrk
    ind2 = np.where((eel >= eelow) & (eel < eebrk))
    if ind2[0].size > 0:
        een_slice = een[ind2]
        term1 = (een_slice**(1.0 - p) - ebn**(1.0 - p)) / (p - 1.0)
        term2 = (ebn**(q - p)) * (ebn**(1.0 - q) - ehn**(1.0 - q)) / (q - 1.0)
        F_E[ind2] = term1 + term2

    # 3. For eebrk <= eel <= eehigh
    ind3 = np.where((eel >= eebrk) & (eel <= eehigh))
    if ind3[0].size > 0:
        een_slice = een[ind3]
        F_E[ind3] = (ebn**(q - p)) * (een_slice**(1.0 - q) - ehn**(1.0 - q)) / (q - 1.0)

    # Final scaling by the reference energy 
    F_E = eeref * F_E

    # Apply optional exponential rolloff factor 
    if Eexp is not None and Eexp > 1.0:
        F_E = F_E * np.exp(-((eel - eeref) / Eexp))

    return F_E

#-------------------------------------------------------------------------------------------------------

def brm2_frc_distrn_vnorm(eel, p, q, eelow, eebrk, eehigh, ref_energy=50.0):
    """
    Provides the integral of the electron flux distribution for the return-
    current loss model, normalized to the spectral flux at a reference energy.

    This is a Python translation of the HESSI IDL procedure
    Brm2_Frc_Distrn_vnorm.pro. The distribution function is proportional to
    (eel + eebrk)^(-p), where eebrk is the potential drop.

    Parameters
    ----------
    eel : np.ndarray
        Array of electron energies (in keV) which are the lower limits for
        the integration.
    p : float
        The power-law index of the injected electron distribution function.
    q : float
        This parameter is unused in this routine.
    eelow, eebrk, eehigh : float
        Low-energy cutoff, potential drop, and high-energy cutoff (keV).
    ref_energy : float, optional
        The reference energy for normalization (in keV). Defaults to 50.0.

    Returns
    -------
    F_E : np.ndarray
        Array containing the integrated electron flux distribution function.
    """
    eeref = ref_energy
    
    # Calculate the normalization factor
    fnorm = (eeref + eebrk)**p / (p - 1.0)

    F_E = np.zeros_like(eel, dtype=float)

    # --- Apply formulas for the two energy regimes ---

    # 1. For lower integration limits below eelow
    ind1 = np.where(eel < eelow)
    if ind1[0].size > 0:
        F_E[ind1] = (eelow + eebrk)**(1.0 - p) - (eehigh + eebrk)**(1.0 - p)

    # 2. For lower integration limits between eelow and eehigh
    ind2 = np.where((eel >= eelow) & (eel <= eehigh))
    if ind2[0].size > 0:
        eel_slice = eel[ind2]
        F_E[ind2] = (eel_slice + eebrk)**(1.0 - p) - (eehigh + eebrk)**(1.0 - p)

    # Final scaling
    F_E = fnorm * F_E

    return F_E

#-----------------------------------------------------------------------------------------------------------

def brm2_fthin(eel, eph, eelow, eebrk, eehigh, p, q, z, efd=True):
    """
    Returns the integrand for the thin-target bremsstrahlung integration.

    This is a Python translation of the HESSI IDL function Brm2_FThin.pro.
    It computes the value to be integrated over electron energy to find the
    photon flux.

    Parameters
    ----------
    eel : np.ndarray
        2D array of electron energies (abscissas) from brm_gauleg.
        Shape is (n_photon_energies, n_integration_points).
    eph : np.ndarray
        1D array of photon energies. Each element corresponds to a row in `eel`.
    elow, eebrk, ehigh : float
        Parameters for the electron distribution: low-energy cutoff, break
        energy, and high-energy cutoff (keV).
    p, q : float
        Power-law indices below and above the break energy.
    z : float
        Mean atomic number of the target plasma.
    efd : bool, optional
        If True (default), the electron distribution is treated as a flux
        distribution. If False, it's treated as a density distribution.

    Returns
    -------
    fthin : np.ndarray
        Array of integrands corresponding to the input array `eel`.
    """
    mc2 = 510.98  # Electron rest mass energy in keV
    clight = 2.9979e10  # Speed of light in cm/s

    # The IDL code uses `eph(l MOD N_Elements(eph))` to align the 1D eph
    # array with the 2D eel array. In NumPy, we can achieve this by
    # reshaping eph to ensure it broadcasts correctly.
    # If eel is shape (M, N) and eph is shape (M,), we need eph as (M, 1).
    if eph.ndim == 1 and eel.ndim == 2:
        eph_2d = eph[:, np.newaxis]
    else:
        eph_2d = eph

    # Call our previously translated helper functions
    cross = brm_bremcross(eel, eph_2d, z)
    fcn = brm2_distrn(eel, p, q, eelow, eebrk, eehigh)

    if efd:
        # Case for electron FLUX distribution
        fthin = fcn * cross * (mc2 / clight)
    else:
        # Case for electron DENSITY distribution
        gamma = (eel / mc2) + 1.0
        fthin = fcn * cross * np.sqrt(eel * (eel + 2.0 * mc2)) / gamma

    return fthin

#------------------------------------------------------------------------------------------------

def brm2_dmlin(eph, ehigh_arr, maxfcn, rerr, eelow, eebrk, eehigh, p, q, z, efd=True):
    """
    Integrates a function via the method of Gaussian quadrature for the thin-target model.

    This is a Python translation of the HESSI IDL function Brm2_Dmlin.pro.
    It repeatedly doubles the number of points evaluated until convergence is
    obtained or the maximum number of points is reached. The integral is split
    into two parts (below and above the break energy) to handle the
    discontinuity.

    Parameters
    ----------
    eph : np.ndarray
        1D array of photon energies for which the flux is calculated.
    ehigh_arr : np.ndarray
        1D array of upper integration limits (must be same size as eph).
    maxfcn : int
        Maximum number of points for the Gaussian quadrature integration.
    rerr : float
        Desired relative error for evaluation of the integrals.
    eelow, eebrk, eehigh : float
        Parameters for the electron distribution (keV).
    p, q, z : float
        Power-law indices and mean atomic number.
    efd : bool, optional
        Flag for electron flux distribution. Defaults to True.

    Returns
    -------
    tuple of (np.ndarray, np.ndarray)
        - dmlin (np.ndarray): Array of estimates of the integrals.
        - ier (np.ndarray): Array of error flags (0=converged, 1=not converged).
    """
    # Initialize output arrays
    intsum1 = np.zeros_like(eph, dtype=float)
    intsum2 = np.zeros_like(eph, dtype=float)
    ier1 = np.zeros_like(eph, dtype=int)
    ier2 = np.zeros_like(eph, dtype=int)

    nlim = 12  # Max possible order of Gaussian quadrature is 2^nlim

    # --- Part 1: Integrate from photon energy up to the break energy ---
    # Find which photon energies are below the break energy
    p2 = np.where(eph < eebrk)[0]
    if p2.size > 0 and eebrk > eelow:
        # For photons with energy less than the low cutoff, start integral at eelow
        a = np.maximum(eph[p2], eelow)
        b = np.full_like(a, eebrk)

        # Logarithmic integration variables
        a_lg = np.log10(a)
        b_lg = np.log10(b)
        l = np.arange(p2.size) # Indices to track for convergence

        # Loop until convergence
        for ires in range(2, nlim + 1):
            npoint = 2**ires
            if npoint > maxfcn:
                ier1[p2[l]] = 1 # Mark as not converged
                break

            eph1 = eph[p2[l]]
            lastsum1 = intsum1[p2[l]].copy()

            # Perform the outer integration
            xi, wi = brm_gauleg(a_lg[l], b_lg[l], npoint)
            integrand = brm2_fthin(10**xi, eph1, eelow, eebrk, eehigh, p, q, z, efd)
            
            # Sum over the integration points (axis=1)
            current_sum = np.sum(10**xi * np.log(10) * wi * integrand, axis=1)
            intsum1[p2[l]] = current_sum

            # Check for convergence
            l1 = np.abs(intsum1[p2[l]] - lastsum1)
            l2 = rerr * np.abs(intsum1[p2[l]])
            
            converged_indices = np.where(l1 <= l2)[0]
            l = np.delete(l, converged_indices) # Remove converged elements
            
            if l.size == 0:
                break # All have converged
        if l.size > 0:
            ier1[p2[l]] = 1


    # --- Part 2: Integrate from the break energy up to the high-energy cutoff ---
    p3 = np.where(eph < eehigh)[0]
    if p3.size > 0 and eehigh > eebrk:
        # Start integration from the break energy
        a = np.full_like(eph[p3], eebrk)
        # For photons with energy above the break, start integral there instead
        a = np.maximum(a, eph[p3])
        b = np.full_like(a, eehigh)
        
        a_lg = np.log10(a)
        b_lg = np.log10(b)
        l = np.arange(p3.size) # Indices to track for convergence

        # Loop until convergence
        for ires in range(2, nlim + 1):
            npoint = 2**ires
            if npoint > maxfcn:
                ier2[p3[l]] = 1
                break

            eph1 = eph[p3[l]]
            lastsum2 = intsum2[p3[l]].copy()

            xi, wi = brm_gauleg(a_lg[l], b_lg[l], npoint)
            integrand = brm2_fthin(10**xi, eph1, eelow, eebrk, eehigh, p, q, z, efd)
            current_sum = np.sum(10**xi * np.log(10) * wi * integrand, axis=1)
            intsum2[p3[l]] = current_sum
            
            l1 = np.abs(intsum2[p3[l]] - lastsum2)
            l2 = rerr * np.abs(intsum2[p3[l]])

            converged_indices = np.where(l1 <= l2)[0]
            l = np.delete(l, converged_indices)
            
            if l.size == 0:
                break
        if l.size > 0:
            ier2[p3[l]] = 1

    # Total flux is the sum of the two parts
    dmlin = intsum1 + intsum2
    ier = ier1 + ier2
    return dmlin, ier

# July 07, 2025 ----------------------------------------------------------------------------------------------------------
def brm_finner(eel, eph, z):
    """
    Returns the integrand for the inner bremsstrahlung integration (Version 1).

    This is a Python translation of the HESSI IDL function Brm_FInner.pro.

    Parameters
    ----------
    eel : np.ndarray
        2D array of electron energies (abscissas) from brm_gauleg.
    eph : np.ndarray
        1D array of photon energies. Each element corresponds to a row in `eel`.
    z : float
        Mean atomic number of the target plasma.

    Returns
    -------
    np.ndarray
        Array of integrands for the inner numerical integration.
    """
    mc2 = 510.98

    # The IDL code uses `eph(l MOD N_Elements(eph))` to align the 1D eph
    # array with the 2D eel array. We do this with broadcasting.
    eph_2d = eph[:, np.newaxis] if eph.ndim == 1 and eel.ndim == 2 else eph
    
    # Call helpers we've already built
    cross = brm_bremcross(eel, eph_2d, z)
    dedt = brm_eloss(eel)
    
    # Calculate gamma and relativistic momentum * c
    gamma = (eel / mc2) + 1.0
    pc = np.sqrt(eel * (eel + 2.0 * mc2))
    
    # Combine terms for the final integrand
    finner = cross * pc / dedt / gamma
    
    return finner

# July 07, 2025 ===================================================================
# (replaces the old brm_v1_dmlini)
#

def brm_v1_dmlini(a, b, maxfcn, rerr, eph, z):
    """
    Integrates a function via Gaussian quadrature (Version 1, inner loop).
    (Corrected to handle all scalar/array input combinations)
    """
    nlim = 12

    # --- FIX: Robustly determine the number of calculations to perform ---
    if isinstance(a, np.ndarray) and a.ndim > 0:
        n_elements = len(a)
    elif isinstance(b, np.ndarray) and b.ndim > 0:
        n_elements = len(b)
    elif isinstance(eph, np.ndarray) and eph.ndim > 0:
        n_elements = len(eph)
    else:
        n_elements = 1 # All inputs are scalars
    # -------------------------------------------------------------------

    intsum = np.zeros(n_elements, dtype=float)
    lastsum = np.zeros(n_elements, dtype=float)
    ier4 = np.zeros(n_elements, dtype=int)
    l_indices = np.arange(n_elements)

    for ires in range(1, nlim + 1):
        npoint = 2**ires
        if npoint > maxfcn:
            if l_indices.size > 0:
                ier4[l_indices] = 1
            break
        
        # Check if inputs are arrays before slicing
        a_slice = a[l_indices] if isinstance(a, np.ndarray) else a
        b_slice = b[l_indices] if isinstance(b, np.ndarray) else b
        eph_slice = eph[l_indices] if isinstance(eph, np.ndarray) else eph

        lastsum[l_indices] = intsum[l_indices]

        xi, wi = brm_gauleg(a_slice, b_slice, npoint)
        integrand = brm_finner(xi, eph_slice, z)
        current_sum = np.sum(wi * integrand, axis=1)
        intsum[l_indices] = current_sum

        l1 = np.abs(intsum[l_indices] - lastsum[l_indices])
        l2 = rerr * np.abs(intsum[l_indices])
        converged_mask = (l1 <= l2)
        l_indices = l_indices[~converged_mask]

        if l_indices.size == 0:
            break
            
    if l_indices.size > 0:
        ier4[l_indices] = 1

    return intsum, ier4

# July 07, 2025 ====================================================== 

def brm_v1_distrn(gamma, gamlow, gambrk, gamhigh, p, q):
    """
    Calculates the value of the V1 electron distribution function.

    This is a Python translation of the HESSI IDL procedure Brm_Distrn.pro.
    The distribution is a function of gamma and is normalized such that
    the integral from gamlow to gamhigh is 1.

    Parameters
    ----------
    gamma : np.ndarray
        Array of Lorentz factors.
    gamlow, gambrk, gamhigh : float
        Lorentz factors for the low-energy cutoff, break, and high-energy cutoff.
    p, q : float
        Power-law indices below and above the break.

    Returns
    -------
    fcn : np.ndarray
        The value of the normalized electron distribution function.
    """
    # Calculate the normalization coefficient, k
    denoma = ((gambrk - 1.0)**(1.0 - p)) - ((gamlow - 1.0)**(1.0 - p))
    denoma = denoma * (1.0 - q)
    denomb = ((gamhigh - 1.0)**(1.0 - q)) - ((gambrk - 1.0)**(1.0 - q))
    denomb = denomb * (1.0 - p) * ((gambrk - 1.0)**(q - p))
    denom = denoma + denomb
    k = (1.0 - q - p + (p * q)) / denom

    fcn = np.zeros_like(gamma, dtype=float)

    # For gammas between gamlow and gambrk
    mask1 = (gamma >= gamlow) & (gamma <= gambrk)
    fcn[mask1] = (gamma[mask1] - 1.0)**(-p)

    # For gammas between gambrk and gamhigh
    mask2 = (gamma > gambrk) & (gamma <= gamhigh)
    fcn[mask2] = ((gambrk - 1.0)**(q - p) * (gamma[mask2] - 1.0)**(-q))

    # Apply the normalization
    fcn = fcn * k
    return fcn


# July 07, 2025 =============================================================
# To be added to solarflaremodels.py (replaces the old brm_v1_fthick)

def brm_v1_fthick(eo, eph, maxfcn, eebrk, gamlow, gambrk, gamhigh,
                  p, q, rerr, z, efd=True):
    """
    Returns the integrand for the outer bremsstrahlung integration (Version 1).
    (Corrected for NumPy broadcasting error)
    """
    mc2 = 510.98
    clight = 2.9979e10

    eph_2d = eph[:, np.newaxis] if eph.ndim == 1 and eo.ndim == 2 else eph
    
    # --- FIX: Create a 2D array of photon energies that matches eo's shape ---
    eph_broadcast = np.broadcast_to(eph_2d, eo.shape)

    gamma = (eo / mc2) + 1.0
    fcn = brm_v1_distrn(gamma, gamlow, gambrk, gamhigh, p, q)

    crosint = np.zeros_like(eo, dtype=float)
    ier3 = np.zeros_like(eo, dtype=int)
    
    # Case 1: Integration range crosses the break energy
    w1_mask = (eph_2d < eebrk) & (eo > eebrk)
    if np.any(w1_mask):
        # Use the broadcasted array for indexing here
        eph_w1 = eph_broadcast[w1_mask]
        eo_w1 = eo[w1_mask]
        
        crosintl, ier4_l = brm_v1_dmlini(eph_w1, eebrk, maxfcn, rerr, eph_w1, z)
        crosinth, ier4_h = brm_v1_dmlini(eebrk, eo_w1, maxfcn, rerr, eph_w1, z)
        
        crosint[w1_mask] = crosintl + crosinth
        ier3[w1_mask] = ier4_l + ier4_h

    # Case 2: Integration range does NOT cross the break energy
    w2_mask = ~w1_mask
    if np.any(w2_mask):
        # And use the broadcasted array for indexing here as well
        eph_w2 = eph_broadcast[w2_mask]
        eo_w2 = eo[w2_mask]
        
        crosint_w2, ier4_w2 = brm_v1_dmlini(eph_w2, eo_w2, maxfcn, rerr, eph_w2, z)
        crosint[w2_mask] = crosint_w2
        ier3[w2_mask] = ier4_w2
        
    if efd:
        fthick = fcn * crosint * (mc2 / clight)
    else:
        fthick = fcn * crosint * np.sqrt(eo * (eo + 2.0 * mc2))
        
    return fthick, ier3


# July 07, 2025 ==============================================================================

def brm_v1_dmlino(a, b, maxfcn, rerr, eph, eebrk, gamlow, gambrk, gamhigh,
                  p, q, z, efd=True):
    """
    Performs the outer Gaussian quadrature integration (Version 1).

    This is a Python translation of the HESSI IDL function Brm_DmlinO.pro.

    Returns
    -------
    tuple of (np.ndarray, np.ndarray, np.ndarray)
        - intsum (np.ndarray): The array of integral estimates.
        - ier1 (np.ndarray): Error flags for the outer integration.
        - ier2 (np.ndarray): Accumulated error flags from the inner integration.
    """
    nlim = 12
    n_elements = len(a) if isinstance(a, np.ndarray) else 1

    intsum = np.zeros(n_elements, dtype=float)
    lastsum = np.zeros(n_elements, dtype=float)
    ier1 = np.zeros(n_elements, dtype=int)
    ier2 = np.zeros(n_elements, dtype=int)

    l_indices = np.arange(n_elements)

    for ires in range(1, nlim + 1):
        npoint = 2**ires
        if npoint > maxfcn:
            if l_indices.size > 0:
                ier1[l_indices] = 120
            break

        a_slice = a[l_indices] if isinstance(a, np.ndarray) else a
        eph_slice = eph[l_indices]
        lastsum[l_indices] = intsum[l_indices]

        # Get the abscissas and weights for the outer integration
        xo, wo = brm_gauleg(a_slice, b, npoint)

        # The outer integrand calls the inner integrator
        fthick, ier3 = brm_v1_fthick(xo, eph_slice, maxfcn, eebrk, gamlow,
                                     gambrk, gamhigh, p, q, rerr, z, efd)

        current_sum = np.sum(wo * fthick, axis=1)
        intsum[l_indices] = current_sum
        
        # Accumulate the error flags from the inner integration
        ier2[l_indices] += np.sum(ier3, axis=1)

        l1_check = np.abs(intsum[l_indices] - lastsum[l_indices])
        l2_check = rerr * np.abs(intsum[l_indices])

        converged_mask = (l1_check <= l2_check)
        l_indices = l_indices[~converged_mask]

        if l_indices.size == 0:
            break

    if l_indices.size > 0:
        ier1[l_indices] = 120

    return intsum, ier1, ier2


# To be added to solarflaremodels.py

def brm_v1_thicktarget(eph, a):
    """
    Computes the thick-target spectrum using the Version 1 algorithm.

    This is a Python translation of the HESSI IDL function Brm_BremThick.pro.
    """
    # Unpack parameters
    p, eebrk, q, eelow, eehigh = a[1], a[2], a[3], a[4], a[5]
    efd = True  # Use electron flux distribution

    # Physical constants
    mc2 = 510.98
    clight = 2.9979e10
    au = 1.496e13
    r0 = 2.8179e-13
    maxfcn = 2048
    z = 1.2
    rerr = 0.001

    # Convert energies to gamma factors
    gamlow = (eelow / mc2) + 1.0
    gambrk = (eebrk / mc2) + 1.0
    gamhigh = (eehigh / mc2) + 1.0

    # Scaling coefficients
    fcoeff = (1.0 / (4.0 * np.pi * au**2)) * (clight**2 / mc2**4)
    decoeff = 4.0 * np.pi * r0**2 * clight * mc2

    flux = np.zeros_like(eph, dtype=float)

    # Calculation is split into two parts around the break energy
    l_mask = eph < eebrk
    h_mask = eph >= eebrk

    if np.any(l_mask):
        eph_l = eph[l_mask]
        emin_l = np.maximum(eph_l, eelow)

        # Integrate from emin to eebrk
        fluxl, _, _ = brm_v1_dmlino(emin_l, eebrk, maxfcn, rerr, eph_l, eebrk,
                                    gamlow, gambrk, gamhigh, p, q, z, efd)
        # Integrate from eebrk to eehigh
        fluxh, _, _ = brm_v1_dmlino(np.full_like(eph_l, eebrk), eehigh, maxfcn,
                                    rerr, eph_l, eebrk, gamlow, gambrk,
                                    gamhigh, p, q, z, efd)
        flux[l_mask] = fluxl + fluxh

    if np.any(h_mask):
        eph_h = eph[h_mask]
        # Integrate from eph to eehigh
        flux_h, _, _ = brm_v1_dmlino(eph_h, eehigh, maxfcn, rerr, eph_h,
                                     eebrk, gamlow, gambrk, gamhigh, p, q, z, efd)
        flux[h_mask] = flux_h

    # Apply final scaling
    final_flux = (fcoeff / decoeff) * flux
    return final_flux


# July 07, 2025 ==== PyXSPEC wrapper

def thick_v1(engs, params, flux, fluxerr, modelName):
    """
    XSPEC wrapper for the original 'Version 1' thick-target model.
    This wrapper is for the full broken power-law model.
    """
    engs = np.array(engs, dtype=float)
    
    # The norm is the last parameter added by XSPEC
    #norm = params[-1]
    # The shape parameters are all parameters BEFORE the last one
    shape_params = params[:-1]

    # Create the 6-element 'a' array for the engine
    a = np.concatenate(([1.0], shape_params))
    
    photon_energies = (engs[:-1] + engs[1:]) / 2.0
    
    # Call the Version 1 engine
    flux_unnorm = brm_v1_thicktarget(photon_energies, a)
    
    final_flux = 1.0e35 * flux_unnorm
    #final_flux = norm * 1.0e35 * flux_unnorm
    flux[:] = final_flux


#------------ Thick-target funcions --------------------------------------------------------------------------------------

def brm2_check_energies(eelow, eebrk, eehigh, return_current=False, **kwargs):
    """
    Clips eebrk to be within [eelow, eehigh] unless using the
    return_current model.

    This is a Python translation of the HESSI IDL procedure
    brm2_check_energies.pro.

    Parameters
    ----------
    eelow, eebrk, eehigh : float
        Low-energy cutoff, break energy, and high-energy cutoff.
    return_current : bool
        If True, eebrk is not modified.

    Returns
    -------
    float
        The potentially modified eebrk.
    """
    if not return_current:
        if eebrk < eelow:
            eebrk = eelow
        if eebrk > eehigh:
            eebrk = eehigh
    return eebrk

#-----------------------------------------------------------------------------------------------

def brm2_fouter(eel, eph, eelow, eebrk, eehigh, p, q, z,
                independent_norm=False, return_current=False,
                ref_energy=50.0, Eexp=None):
    """
    Returns the integrand for the outer bremsstrahlung integration for the
    thick-target model.

    This is a Python translation of the HESSI IDL function Brm2_Fouter.pro.
    It combines the bremsstrahlung cross-section, electron energy loss rate,
    and the integral of the electron distribution function.

    Parameters
    ----------
    eel : np.ndarray
        2D array of electron energies (abscissas) from brm_gauleg.
    eph : np.ndarray
        1D array of photon energies corresponding to rows in `eel`.
    eelow, eebrk, eehigh : float
        Low-energy cutoff, break energy, and high-energy cutoff (keV).
    p, q : float
        Power-law indices below and above the break energy.
    z : float
        Mean atomic number of the target plasma.
    independent_norm : bool, optional
        If True, use the v-norm distribution. Defaults to False.
    return_current : bool, optional
        If True, use the return-current distribution. Defaults to False.
    ref_energy : float, optional
        Reference energy for v-norm/rc-norm distributions. Defaults to 50.0.
    Eexp : float, optional
        Exponential rolloff energy for v-norm distribution. Defaults to None.

    Returns
    -------
    fouter : np.ndarray
        Array of integrands corresponding to the input array `eel`.
    """
    mc2 = 510.98

    # Ensure eph is broadcastable to the shape of eel
    eph_2d = eph[:, np.newaxis] if eph.ndim == 1 and eel.ndim == 2 else eph

    # --- Call our helper functions to get the physics components ---
    cross = brm_bremcross(eel, eph_2d, z)
    dedt = brm_eloss(eel)

    # --- Calculate other necessary quantities ---
    gamma = (eel / mc2) + 1.0
    pc = np.sqrt(eel * (eel + 2.0 * mc2)) # Relativistic momentum * c

    # --- Select the appropriate integrated electron distribution function ---
    if return_current:
        # Call the return-current model distribution 
        F_E = brm2_frc_distrn_vnorm(eel, p, q, eelow, eebrk, eehigh, ref_energy=ref_energy)
    elif independent_norm:
        # Call the independent normalization model distribution 
        F_E = brm2_f_distrn_vnorm(eel, p, q, eelow, eebrk, eehigh, Eexp=Eexp, ref_energy=ref_energy)
    else:
        # Call the standard integrated distribution 
        F_E = brm2_f_distrn(eel, p, q, eelow, eebrk, eehigh)

    # --- Combine all components into the final integrand ---
    # Note: dedt can be zero at very low energies, leading to division by zero.
    # We add a small number to the denominator to avoid NaNs.
    fouter = F_E * cross * pc / (dedt * gamma + 1e-99)

    return fouter

#-----------------------------------------------------------------------------------------------

def brm2_dmlino_int(l_indices, eph, a_lg, b_lg, intsum, ier, maxfcn, rerr,
                    eelow, eebrk, eehigh, p, q, z, **kwargs):
    """
    Performs the core Gaussian quadrature integration loop for a given segment.

    This is a Python translation of the HESSI IDL procedure
    brm2_dmlino_int.pro. This function is intended to be called by
    brm2_dmlino.

    Parameters
    ----------
    l_indices, eph, a_lg, b_lg : np.ndarray
        Indices to operate on, photon energies, log of lower and upper
        integration limits.
    intsum, ier : np.ndarray
        The arrays for the integral sum and error flags to be modified in-place.
    maxfcn, rerr, eelow, eebrk, eehigh, p, q, z :
        Model and integration parameters.
    **kwargs :
        Additional keywords (e.g., independent_norm) to pass to brm2_fouter.
    """
    nlim = 12
    # Loop from 2^2 to 2^12 points, checking for convergence
    for ires in range(2, nlim + 1):
        npoint = 2**ires
        if npoint > maxfcn:
            ier[l_indices] = 1 # Mark as not converged
            break

        # Slices of arrays for the current non-converged points
        eph1 = eph[l_indices]
        lastsum = intsum[l_indices].copy()

        # Perform the integration using our helper functions
        xi, wi = brm_gauleg(a_lg, b_lg, npoint)
        integrand = brm2_fouter(10**xi, eph1, eelow, eebrk, eehigh, p, q, z, **kwargs)

        # Sum over integration points (axis=1)
        current_sum = np.sum(10**xi * np.log(10.0) * wi * integrand, axis=1)
        intsum[l_indices] = current_sum

        # Check for convergence
        l1 = np.abs(current_sum - lastsum)
        l2 = rerr * np.abs(current_sum)
        
        # Find which points have not yet converged and continue the loop with only them
        not_converged_mask = np.where(l1 > l2)[0]
        if not_converged_mask.size == 0:
            return # All points in this batch have converged

        # Update all arrays to only refer to the non-converged points
        l_indices = l_indices[not_converged_mask]
        a_lg = a_lg[not_converged_mask]
        b_lg = b_lg[not_converged_mask]

    # If the loop finishes without convergence, mark the remaining points
    if l_indices.size > 0:
        ier[l_indices] = 1


def brm2_dmlino(eph, ehigh_arr, maxfcn, rerr, eelow, eebrk, eehigh, p, q, z, **kwargs):
    """
    Manages the full thick-target integration by splitting it into segments.

    This is a Python translation of the HESSI IDL function Brm2_DmlinO.pro.
    It is the main integration engine for the Version 2 thick-target model.

    Parameters
    ----------
    (Same as brm2_dmlin, but for thick-target)

    Returns
    -------
    tuple of (np.ndarray, np.ndarray)
        - dmlino (np.ndarray): Array of estimates of the integrals.
        - ier (np.ndarray): Array of error flags.
    """
    mc2 = 510.98
    clight = 2.9979e10

    # Ensure eebrk is valid
    eebrk = brm2_check_energies(eelow, eebrk, eehigh, **kwargs)

    # Sort the characteristic energies to handle integration segments
    en_vals = np.sort([eelow, eebrk, eehigh])

    # Initialize results arrays
    intsum1, intsum2, intsum3 = (np.zeros_like(eph) for _ in range(3))
    ier1, ier2, ier3 = (np.zeros_like(eph, dtype=int) for _ in range(3))

    # --- Part 1: Integral from eph up to en_vals[0] (usually eelow) ---
    p1_indices = np.where(eph < en_vals[0])[0]
    if p1_indices.size > 0:
        a_lg = np.log10(eph[p1_indices])
        b_lg = np.log10(np.full_like(a_lg, en_vals[0]))
        brm2_dmlino_int(p1_indices, eph, a_lg, b_lg, intsum1, ier1, maxfcn, rerr,
                        eelow, eebrk, eehigh, p, q, z, **kwargs)

    # --- Part 2: Integral from max(eph, en_vals[0]) up to en_vals[1] (usually eebrk) ---
    if en_vals[1] > en_vals[0]:
        p2_indices = np.where(eph < en_vals[1])[0]
        if p2_indices.size > 0:
            a = np.maximum(eph[p2_indices], en_vals[0])
            b_lg = np.log10(np.full(a.shape, en_vals[1]))
            brm2_dmlino_int(p2_indices, eph, np.log10(a), b_lg, intsum2, ier2, maxfcn,
                            rerr, eelow, eebrk, eehigh, p, q, z, **kwargs)

    # --- Part 3: Integral from max(eph, en_vals[1]) up to en_vals[2] (usually eehigh) ---
    if en_vals[2] > en_vals[1]:
        p3_indices = np.where(eph < en_vals[2])[0]
        if p3_indices.size > 0:
            a = np.maximum(eph[p3_indices], en_vals[1])
            b_lg = np.log10(np.full(a.shape, en_vals[2]))
            brm2_dmlino_int(p3_indices, eph, np.log10(a), b_lg, intsum3, ier3, maxfcn,
                            rerr, eelow, eebrk, eehigh, p, q, z, **kwargs)

    # The final unscaled flux is the sum of the parts, with a final coefficient
    dmlino = (intsum1 + intsum2 + intsum3) * (mc2 / clight)
    ier = ier1 + ier2 + ier3
    return dmlino, ier


#-------------------------------------------------------------------------------------------------
def brm2_thicktarget(eph, a, **kwargs):
    """
    Computes the thick-target bremsstrahlung spectrum from an isotropic electron
    distribution. This is the main "Version 2" engine.

    This is a Python translation of the HESSI IDL function Brm2_ThickTarget.pro.

    Parameters
    ----------
    eph : np.ndarray
        Array of photon energies (in keV).
    a : list or np.ndarray
        List of 6 parameters describing the electron distribution:
        a[0]: Normalization (not used here, applied in wrapper)
        a[1]: p (index below break)
        a[2]: eebrk (break energy)
        a[3]: q (index above break)
        a[4]: eelow (low-energy cutoff)
        a[5]: eehigh (high-energy cutoff)
    **kwargs :
        Additional keywords (e.g., independent_norm) to pass to the
        integration routines.

    Returns
    -------
    np.ndarray
        The computed photon flux, scaled by physical constants but not the
        overall normalization factor a[0].
    """
    # Unpack parameters
    p, eebrk, q, eelow, eehigh = a[1], a[2], a[3], a[4], a[5]

    # --- Physical constants and integration parameters ---
    mc2 = 510.98
    clight = 2.9979e10
    au = 1.496e13
    r0 = 2.8179e-13
    maxfcn = 2048
    z = 1.2
    rerr = 1.0e-4
    
    # Check for invalid energy range
    if eelow >= eehigh:
        return np.zeros_like(eph)

    # --- Coefficients for scaling the final result ---
    # Photon flux coefficient
    fcoeff = (1.0 / (4.0 * np.pi * au**2)) * (clight**2 / mc2**4)
    # Energy loss rate coefficient
    decoeff = 4.0 * np.pi * r0**2 * clight

    flux = np.zeros_like(eph)
    iergq = np.zeros_like(eph, dtype=int)

    # Find photon energies within the valid integration range
    valid_indices = np.where((eph > 0) & (eph < eehigh))[0]
    if valid_indices.size == 0:
        print("Warning: All photon energies are outside the valid range [0, eehigh].")
        return flux

    eph_valid = eph[valid_indices]
    ehigh_arr = np.full_like(eph_valid, eehigh)

    # --- Call the main integration engine ---
    flux_unscaled, ier = brm2_dmlino(eph_valid, ehigh_arr, maxfcn, rerr,
                                     eelow, eebrk, eehigh, p, q, z, **kwargs)

    flux[valid_indices] = flux_unscaled
    iergq[valid_indices] = ier

    # Apply final scaling
    final_flux = (fcoeff / decoeff) * flux

    if np.any(iergq > 0):
        print("Warning: Thick-target integration did not converge for some photon energies.")

    return final_flux

#-----------------------------------------------------------------------------------------------------------
# PyXSPEC wrapper functions for thick-target variants and thin-target (July 03, 2025)

def brm2_thintarget_engine(eph, a, **kwargs):
    """
    Top-level engine for the thin-target bremsstrahlung spectrum.
    """
    p, eebrk, q, eelow, eehigh = a[1], a[2], a[3], a[4], a[5]
    mc2, clight, au = 510.98, 2.9979e10, 1.496e13
    maxfcn, z, rerr = 2048, 1.2, 1.0e-4

    if eelow >= eehigh:
        return np.zeros_like(eph)

    fcoeff = (clight / (4.0 * np.pi * au**2)) / mc2**2
    flux = np.zeros_like(eph)
    valid_indices = np.where((eph > 0) & (eph < eehigh))[0]
    if valid_indices.size == 0:
        return flux
        
    eph_valid = eph[valid_indices]
    ehigh_arr = np.full_like(eph_valid, eehigh)

    flux_unscaled, ier = brm2_dmlin(eph_valid, ehigh_arr, maxfcn, rerr,
                                    eelow, eebrk, eehigh, p, q, z, **kwargs)
    if np.any(ier > 0):
        print("Warning: Thin-target integration did not converge.")

    flux[valid_indices] = flux_unscaled * fcoeff
    return flux

# Model 1: Standard Thick-Target
def standardthick(engs, params, flux, fluxerr, modelName):
    engs = np.array(engs, dtype=float)
    #norm = params[-1]
    shape_params = params[:-1]
    a = np.concatenate(([1.0], shape_params))
    photon_energies = (engs[:-1] + engs[1:]) / 2.0
    flux_unnorm = brm2_thicktarget(photon_energies, a)
    final_flux = 1.0e35 * flux_unnorm
    #final_flux = norm * 1.0e35 * flux_unnorm
    flux[:] = final_flux

# Model 2: Standard Thin-Target
def standardthin(engs, params, flux, fluxerr, modelName):
    engs = np.array(engs, dtype=float)
    #norm = params[-1]
    shape_params = params[:-1]
    a = np.concatenate(([1.0], shape_params))
    photon_energies = (engs[:-1] + engs[1:]) / 2.0
    flux_unnorm = brm2_thintarget_engine(photon_energies, a)
    final_flux = 1.0e55 * flux_unnorm
    #final_flux = norm * 1.0e55 * flux_unnorm
    flux[:] = final_flux

# Model 3: Thick-Target V-Norm
def thickvnorm(engs, params, flux, fluxerr, modelName):
    engs = np.array(engs, dtype=float)
    #norm = params[-1]
    shape_params = params[:-1]
    a = np.concatenate(([1.0], shape_params))
    photon_energies = (engs[:-1] + engs[1:]) / 2.0
    ref_energy = a[6] # The 7th element of the reconstructed 'a' array
    flux_unnorm = brm2_thicktarget(photon_energies, a, 
                                   independent_norm=True, ref_energy=ref_energy)
    final_flux = 1.0e35 * flux_unnorm
    #final_flux = norm * 1.0e35 * flux_unnorm
    flux[:] = final_flux

# Model 4: Thick-Target Return-Current
def thickrc(engs, params, flux, fluxerr, modelName):
    engs = np.array(engs, dtype=float)
    #norm = params[-1]
    shape_params = params[:-1]
    a = np.concatenate(([1.0], shape_params))
    photon_energies = (engs[:-1] + engs[1:]) / 2.0
    ref_energy = a[6]
    flux_unnorm = brm2_thicktarget(photon_energies, a, 
                                   return_current=True, 
                                   independent_norm=True, 
                                   ref_energy=ref_energy)
    final_flux = 1.0e35 * flux_unnorm
    #final_flux = norm * 1.0e35 * flux_unnorm
    flux[:] = final_flux

#===================================================================================
# July 29, 2025
# incorporating the warm target model
# This is a helper function
def thermal_bremsstrahlung(energies, em, kt):
    """
    Calculates a simplified thermal bremsstrahlung spectrum.

    Parameters
    ----------
    energies : np.ndarray
        Array of photon energies (in keV).
    em : float
        Emission measure in units of 10^49 cm^-3.
    kt : float
        Plasma temperature in keV.

    Returns
    -------
    np.ndarray
        The thermal photon flux in photons / s / cm^2 / keV.
    """
    # Constants
    au = 1.496e13  # cm
    const = 3.02e-15
    
    # Simplified formula, approximating the Gaunt factor
    flux = (const / (4 * np.pi * au**2)) * (em * 1e49) * np.exp(-energies / kt) / np.sqrt(kt)
    return flux

# Warm target engine
def warm_thick_engine(eph, a):
    """
    Top-level engine for the warm thick-target model.
    """
    # Unpack all 10 parameters
    norm_nt, p, eebrk, q, eelow, eehigh = a[0:6]
    warm_dens, warm_temp, warm_len, abund = a[6:10]

    # --- 1. Calculate the standard non-thermal thick-target component ---
    # We use our existing, debugged engine for this.
    non_thermal_flux = brm2_thicktarget(eph, a[0:6])

    # --- 2. Calculate the properties of the additional thermal component ---
    # These formulas are a direct translation from f_thick_warm.txt
    me_keV = 511.0
    cc = 2.99e10
    KK = 2.6e-18
    
    np_warm = warm_dens * 1e10
    Tloop = warm_temp
    L = warm_len * 1e8

    # Avoid division by zero if density is zero
    if np_warm == 0:
        return non_thermal_flux

    ll = Tloop**2 / (2.0 * KK * np_warm)
    Emin = Tloop * 3.0 * (5.0 * ll / L)**4
    
    # Ensure Emin is not zero to avoid division by zero in the next step
    if Emin == 0:
        return non_thermal_flux

    EM_add = (3. * np.pi / (2. * KK * cc) * np.sqrt(me_keV / 8.) * Tloop**2 / np.sqrt(Emin) * (norm_nt * 1e35))
    
    EM49 = EM_add * 1e-49 # Convert to units of 10^49 cm^-3

    # --- 3. Calculate the thermal flux from this new component ---
    # Note: The 'abund' parameter is not used in our simplified thermal function,
    # but is kept for consistency with the IDL model's parameter count.
    thermal_flux_add = thermal_bremsstrahlung(eph, EM49, Tloop)

    # --- 4. The final model is the sum of the two components ---
    return non_thermal_flux + thermal_flux_add

# Model 5: Warm-thick-target (WTT) model
def warmthick(engs, params, flux, fluxerr, modelName):
    """
    pyXSPEC wrapper for the warm thick-target model.
    """
    engs = np.array(engs, dtype=float)
    shape_params = params
    
    # Reconstruct the 'a' array for our engine, using a placeholder norm.
    # The engine expects the non-thermal norm as the first parameter.
    a = np.concatenate(([1.0], shape_params))
    
    photon_energies = (engs[:-1] + engs[1:]) / 2.0
    
    # Call the new warm-target physics engine
    flux_unnorm = warm_thick_engine(photon_energies, a)
    
    # Provide the un-normalized flux to XSPEC.
    # The scaling factor is the same as the standard thick-target model.
    final_flux = 1.0e35 * flux_unnorm
    flux[:] = final_flux

#======================================================================================

# July 29, 2025 
# implementation of the Non-Uniform Ionization (NUI) Model using a step-function ionization profile for now
# Step 1: Helper functions and Engine for NUI model. This is a large block of code containing the Python translations of nui_dmlino_m, nui_f_distrn, nui_fouter, nui_dmlino, and the top-level brm2_nui engine.
# ==============================================================================
# HELPER FUNCTIONS AND ENGINE FOR THE NUI MODEL
# ==============================================================================

def nui_dmlino_m(a, b, maxfcn, rerr, eel, p, ee1, ee0, eelow, eehigh, z):
    """
    Specialized inner integrator for the linear-function NUI model.
    A Python translation of nui_dmlino_m.pro.
    """
    mc2 = 510.98
    lambda_const = 0.55  # From Brown 1973
    
    intsum1 = np.zeros_like(a, dtype=float)
    ier1 = np.zeros_like(a, dtype=int)
    
    # This function is complex and contains physics embedded in the loop.
    # For now, we will return a placeholder. A full translation would be needed
    # if this specific linear-function part of the model is required.
    # This is a highly complex function with many coupled physics terms.
    # A direct translation is a significant undertaking.
    # For now, we will focus on the simpler step-function NUI model.
    print("Warning: The linear-function NUI model (Ee0-Ee1 > 0) is not yet fully implemented.")
    return intsum1, ier1


def nui_f_distrn(eel, p, ee1, ee0, eelow, eehigh, maxfcn, rerr, z):
    """
    Provides the integral of the single power-law electron flux distribution,
    weighted by the non-uniform ionization profile.
    A Python translation of nui_f_distrn.pro.
    """
    lambda_const = 0.55
    mc2 = 510.98
    F_E = np.zeros_like(eel, dtype=float)

    # Case 1: Fully ionized thick target (ee1 = 0)
    if ee1 == 0.0:
        norm_factor = 1.0 / (eelow**(1.0 - p) - eehigh**(1.0 - p))
        
        mask_below = eel < eelow
        F_E[mask_below] = 1.0
        
        mask_inside = (eel >= eelow) & (eel < eehigh)
        F_E[mask_inside] = norm_factor * (eel[mask_inside]**(1.0 - p) - eehigh**(1.0 - p))
        
        return F_E

    # Case 2: Step-function ionization profile (ee1 == ee0)
    if ee1 == ee0:
        temp = eel**2 / (2. * (eel + mc2)) + ee1**2 / (2. * (ee1 + mc2))
        Ex = temp + np.sqrt(temp**2 + 2. * temp * mc2)
        
        Ex_clipped = np.clip(Ex, eelow, eehigh)
        
        term1 = (np.maximum(eel, eelow)**(1.0 - p) - Ex_clipped**(1.0 - p))
        term2 = (1.0 + lambda_const) / lambda_const * (Ex_clipped**(1.0 - p) - eehigh**(1.0 - p))
        
        norm_factor = 1.0 / (eelow**(1.0 - p) - eehigh**(1.0 - p))
        F_E = norm_factor * (term1 + term2)
        return F_E
        
    # Case 3: Linear-function ionization profile (not fully implemented yet)
    else:
        # This part requires the full implementation of nui_dmlino_m
        print("Warning: Linear-function NUI model is not yet fully implemented. Using step-function approximation.")
        # Fall back to the step-function as an approximation
        return nui_f_distrn(eel, p, ee1, ee1, eelow, eehigh, maxfcn, rerr, z)


def nui_fouter(eel, eph, maxfcn, rerr, p, ee1, ee0, eelow, eehigh, z):
    """
    Returns the integrand for the outer NUI bremsstrahlung integration.
    A Python translation of nui_fouter.pro.
    """
    mc2 = 510.98
    eph_2d = eph[:, np.newaxis] if eph.ndim == 1 and eel.ndim == 2 else eph
    
    cross = brm_bremcross(eel, eph_2d, z)
    dedt = brm_eloss(eel)
    gamma = (eel / mc2) + 1.0
    pc = np.sqrt(eel * (eel + 2.0 * mc2))
    
    # Call the NUI distribution integral function
    F_E = nui_f_distrn(eel, p, ee1, ee0, eelow, eehigh, maxfcn, rerr, z)
    
    fouter = F_E * cross * pc / (dedt * gamma + 1e-99)
    return fouter


def nui_dmlino(eph, ehigh_arr, maxfcn, rerr, p, ee1, ee0, eelow, eehigh, z):
    """
    Main integration engine for the NUI model.
    A Python translation of nui_dmlino.pro.
    """
    mc2 = 510.98
    clight = 2.9979e10
    
    intsum1 = np.zeros_like(eph, dtype=float)
    ier1 = np.zeros_like(eph, dtype=int)
    intsum2 = np.zeros_like(eph, dtype=float)
    ier2 = np.zeros_like(eph, dtype=int)
    nlim = 12

    # Part 1: Integral from eph up to eelow
    p1_indices = np.where(eph < eelow)[0]
    if p1_indices.size > 0:
        # This part of the integration is complex and often numerically unstable.
        # We will approximate by starting all integrations from eelow.
        pass # For simplicity in this translation, we skip this part.

    # Part 2: Integral from max(eph, eelow) up to eehigh
    p2_indices = np.where(eph < eehigh)[0]
    if p2_indices.size > 0:
        a = np.maximum(eph[p2_indices], eelow)
        b = np.full_like(a, eehigh)
        a_lg, b_lg = np.log10(a), np.log10(b)
        l_indices = np.arange(p2_indices.size)

        for ires in range(2, nlim + 1):
            npoint = 2**ires
            if npoint > maxfcn: ier2[p2_indices[l_indices]] = 1; break
            
            eph1 = eph[p2_indices[l_indices]]
            lastsum2 = intsum2[p2_indices[l_indices]].copy()
            
            xi, wi = brm_gauleg(a_lg[l_indices], b_lg[l_indices], npoint)
            integrand = nui_fouter(10**xi, eph1, maxfcn, rerr, p, ee1, ee0, eelow, eehigh, z)
            current_sum = np.sum(10**xi * np.log(10.0) * wi * integrand, axis=1)
            intsum2[p2_indices[l_indices]] = current_sum
            
            l1 = np.abs(current_sum - lastsum2)
            l2 = rerr * np.abs(current_sum)
            not_converged_mask = l1 > l2
            l_indices = l_indices[not_converged_mask]
            if l_indices.size == 0: break
        if l_indices.size > 0: ier2[p2_indices[l_indices]] = 1

    dmlino = (intsum1 + intsum2) * (mc2 / clight)
    ier = ier1 + ier2
    return dmlino, ier


def brm2_nui_engine(eph, a):
    """
    Top-level engine for the NUI thick-target model.
    A Python translation of brm2_nui.pro.
    """
    p, ee1, ee0_minus_ee1, eelow, eehigh = a[1], a[2], a[3], a[4], a[5]
    ee0 = ee1 + ee0_minus_ee1

    mc2, clight, au, r0 = 510.98, 2.9979e10, 1.496e13, 2.8179e-13
    maxfcn, z, rerr = 2048, 1.2, 1.0e-3
    
    fcoeff = (1.0 / (4.0 * np.pi * au**2)) * (clight**2 / mc2**4)
    decoeff = 4.0 * np.pi * r0**2 * clight
    
    flux = np.zeros_like(eph, dtype=float)
    valid_indices = np.where((eph > 0) & (eph < eehigh))[0]
    
    if valid_indices.size > 0:
        eph_valid = eph[valid_indices]
        ehigh_arr = np.full_like(eph_valid, eehigh)
        
        flux_unscaled, ier = nui_dmlino(eph_valid, ehigh_arr, maxfcn, rerr,
                                        p, ee1, ee0, eelow, eehigh, z)
        
        flux[valid_indices] = flux_unscaled
        if np.any(ier > 0):
            print("Warning: NUI integration did not converge for some energies.")
            
    return (fcoeff / decoeff) * flux

# Step 2: PyXSPEC Wrapper for the model "thicknui"
# Model 6:"thicknui" 
def thicknui(engs, params, flux, fluxerr, modelName):
    """
    pyXSPEC wrapper for the Non-Uniform Ionization (NUI) thick-target model.
    """
    engs = np.array(engs, dtype=float)
    shape_params = params
    
    # Reconstruct the 'a' array for our engine.
    a = np.concatenate(([1.0], shape_params))
    
    photon_energies = (engs[:-1] + engs[1:]) / 2.0
    
    # Call the NUI physics engine
    flux_unnorm = brm2_nui_engine(photon_energies, a)
    
    # Provide the un-normalized flux to XSPEC.
    final_flux = 1.0e35 * flux_unnorm
    flux[:] = final_flux

#======================================================================
# July 29, 2025 
# introducing the thin kappa function
# Step 1: kappa model moves away from the power-law assumption for the electron distribution and uses a kappa distribution instead, which is often used to model particles in space plasmas that are not in perfect thermal equilibrium. 
# ==============================================================================
# NEW HELPER AND ENGINE FOR THE KAPPA DISTRIBUTION MODEL
# ==============================================================================

def ekappa(en, temp_K, kappa_index):
    """
    Calculates a kappa distribution of particle density, normalized to 1.

    A Python translation of the IDL function ekappa.pro.

    Parameters
    ----------
    en : np.ndarray
        Array of electron energies in keV.
    temp_K : float
        Temperature in Kelvin.
    kappa_index : float
        The kappa index, must be > 1.5.

    Returns
    -------
    np.ndarray
        The value of the kappa distribution.
    """
    k_b = 8.617e-8  # Boltzmann constant in keV / K
    
    # Calculate normalization constants
    # gamma is from scipy.special
    scale = gamma(kappa_index + 1.0) / (gamma(kappa_index - 0.5) * (kappa_index - 1.5)**1.5)
    const = 2.0 / (np.sqrt(np.pi) * (k_b * temp_K)**1.5)
    
    # Calculate the kappa distribution formula
    denominator = (1.0 + en / ((kappa_index - 1.5) * k_b * temp_K))**(kappa_index + 1.0)
    kappa_dist = np.sqrt(en) / denominator
    
    return kappa_dist * scale * const


def thin_kappa_engine(eph, a):
    """
    Top-level engine for the thin-target kappa model.
    A Python translation of f_thin_kappa.pro.
    """
    # Unpack parameters
    em_49, temp_keV, kappa, ehigh = a[0], a[1], a[2], a[3]
    
    # Constants
    mc2 = 510.98
    clight = 2.9979e10
    au = 1.496e13
    z = 1.2
    keV2K = 1.16e7 # Conversion from keV to Kelvin
    maxfcn = 2048
    rerr = 1.0e-4
    
    # The kappa distribution function uses temperature in K
    temp_K = temp_keV * keV2K
    
    # Coefficient for final scaling
    fcoeff = (clight / (4.0 * np.pi * au**2)) / mc2**2
    
    # Set up the integration loop
    intsum = np.zeros_like(eph, dtype=float)
    l_indices = np.arange(len(eph))
    
    # This model uses a simpler, single integration from eph to ehigh
    # It does not need the complex convergence loop of the other models
    npoint = 128 # A reasonable number of points for a smooth integrand
    
    # Get abscissas and weights
    xi, wi = brm_gauleg(eph, ehigh, npoint)
    
    # Calculate the integrand
    eph_2d = eph[:, np.newaxis]
    cross = brm_bremcross(xi, eph_2d, z)
    fcn = ekappa(xi, temp_K, kappa)
    gamma = xi / mc2 + 1.0
    
    # The f_thin_kappa model is for a density distribution, not a flux
    integrand = fcn * cross * np.sqrt(xi * (xi + 2.0 * mc2)) / gamma
    
    # Perform the integration
    intsum = np.sum(wi * integrand, axis=1)
    
    # The normalization 'em_49' is an emission measure
    final_flux = 1.0e49 * intsum * fcoeff
    #final_flux = 1.0e49 * em_49 * intsum * fcoeff
    return final_flux

# Step 2: PyXSPEC wrapper for thin-target kappa distribution model
# Model 7: thkappa
def thkappa(engs, params, flux, fluxerr, modelName):
    """
    pyXSPEC wrapper for the thin-target kappa distribution model.
    """
    engs = np.array(engs, dtype=float)
    
    # The normalization (EM) is handled by XSPEC's norm parameter
    #norm = params[-1]
    # The shape parameters are temp, kappa, and ehigh
    shape_params = params[:-1]
    
    # Reconstruct the 'a' array for our engine. The engine expects
    # emission measure as the first parameter.
    a = np.concatenate(([norm], shape_params))
    
    photon_energies = (engs[:-1] + engs[1:]) / 2.0
    
    # The engine returns the fully scaled flux directly
    final_flux = thin_kappa_engine(photon_energies, a)
    
    flux[:] = final_flux
#=============================================================================

# July 29, 2025 
# incorporating the thick_warm_kappa model. This is a very interesting hybrid model. It calculates the bremsstrahlung from a kappa-distributed electron population (similar to thkappa), but it also adds a thermal component that represents the plasma heated by those electrons, similar to the warmthick model.
# Step 1: 
# ==============================================================================
# CORRECTED ENGINE FOR THE WARM-THICK KAPPA MODEL
# ==============================================================================
def thick_warm_kappa_engine(eph, a_shape):
    """
    Top-level engine for the warm thick-target kappa model.
    This version calculates the model SHAPE for a unit normalization (Ndot_35 = 1.0).
    """
    # Unpack the SHAPE parameters
    p_kappa, Tk_keV, ehigh, warm_dens, warm_temp, warm_len, abund = a_shape
    
    # --- Use a fixed unit normalization internally for the calculation ---
    Ndot_35 = 1.0
    Ndot = Ndot_35 * 1.0e35

    # --- Constants and Setup ---
    mc2 = 510.98; clight = 2.9979e10; au = 1.496e13; z = 1.2
    keV2K = 1.16e7; KK = 2.6e-18
    fcoeff = 1.0 / (4.0 * np.pi * au**2)
    
    # --- Part 1: Calculate the Non-Thermal Spectrum Shape ---
    npoint = 128
    xi, wi = brm_gauleg(eph, ehigh, npoint)
    eph_2d = eph[:, np.newaxis]
    cross = brm_bremcross(xi, eph_2d, z)
    
    x = xi
    Tk = Tk_keV
    kappa_index = p_kappa
    
    nVF_E = Ndot * (x / KK) * \
            ((kappa_index - 1.) / (1. + x / (kappa_index * Tk))**(kappa_index - 2.) -
             (kappa_index - 2.) / (1. + x / (kappa_index * Tk))**(kappa_index - 1.))
             
    integrand = nVF_E * cross / mc2
    intsum = np.sum(wi * integrand, axis=1)
    non_thermal_flux = intsum * fcoeff

    # --- Part 2: Calculate and add the warm thermal component shape ---
    np_warm = warm_dens * 1e10
    Tloop = warm_temp
    L = warm_len * 1e8
    
    if np_warm == 0 or Tloop == 0 or L == 0:
        return non_thermal_flux

    ll = Tloop**2 / (2.0 * KK * np_warm)
    Emin = Tloop * 3.0 * (5.0 * ll / L)**4
    
    if Emin == 0:
        return non_thermal_flux

    EM_add = (3. * np.pi / (2. * KK * clight) * np.sqrt(mc2 / 8.) * Tloop**2 / np.sqrt(Emin) * Ndot)
    #EM49 = EM_add * 1e-49

    thermal_flux_add = thermal_bremsstrahlung(eph, EM_add, Tloop)
    
    # --- Part 3: Final shape is the sum of both components ---
    final_flux_shape = non_thermal_flux + thermal_flux_add
    final_flux_shape[~np.isfinite(final_flux_shape)] = 1e-30
    
    return final_flux_shape

# Model 8:

def thwarmkappa(engs, params, flux, fluxerr, modelName):
    """
    pyXSPEC wrapper for the warm thick-target kappa model.
    Normalization is handled by XSPEC. (Corrected version)
    """
    engs = np.array(engs, dtype=float)
    
    # --- FIX: Correctly separate the shape parameters from the norm ---
    # The shape parameters are all parameters BEFORE the last one.
    shape_params = params[:-1]
    
    photon_energies = (engs[:-1] + engs[1:]) / 2.0
    
    # Call the engine to get the un-normalized SHAPE of the spectrum
    flux_shape = thick_warm_kappa_engine(photon_energies, shape_params)
    
    # Provide the un-normalized flux to XSPEC. XSPEC's 'norm' will scale this.
    # The 1.0e35 factor is part of the model's physical definition.
    final_flux = 1.0e35 * flux_shape
    flux[:] = final_flux


#================================================================================
